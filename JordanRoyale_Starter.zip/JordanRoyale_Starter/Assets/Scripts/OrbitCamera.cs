using UnityEngine;

public class OrbitCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0f, 2.4f, -4.5f);
    public float followSpeed = 8f;
    public float sensitivity = 0.12f;
    public float minPitch = -15f, maxPitch = 55f;
    float yaw, pitch = 12f;
    Vector2 lastTouch;
    bool dragging;

    void LateUpdate()
    {
        if (target == null) return;
#if UNITY_EDITOR || UNITY_STANDALONE
        yaw += Input.GetAxis("Mouse X") * 3f;
        pitch -= Input.GetAxis("Mouse Y") * 3f;
#endif
        if (Input.touchCount > 0)
        {
            foreach (Touch touch in Input.touches)
            {
                if (touch.position.x < Screen.width * 0.42f) continue;
                if (touch.phase == TouchPhase.Began) { lastTouch = touch.position; dragging = true; }
                else if (dragging && touch.phase == TouchPhase.Moved)
                {
                    Vector2 delta = touch.position - lastTouch;
                    yaw += delta.x * sensitivity; pitch -= delta.y * sensitivity; lastTouch = touch.position;
                }
                else if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled) dragging = false;
            }
        }
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);
        Quaternion rot = Quaternion.Euler(pitch, yaw, 0);
        Vector3 desired = target.position + rot * offset;
        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * Time.deltaTime);
        transform.rotation = Quaternion.LookRotation(target.position + Vector3.up * 1.4f - transform.position);
    }
}
