using UnityEngine;
using UnityEngine.EventSystems;

public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform background;
    public RectTransform handle;
    public float radius = 70f;
    public Vector2 Value { get; private set; }

    public void OnPointerDown(PointerEventData eventData) { OnDrag(eventData); }
    public void OnDrag(PointerEventData eventData)
    {
        if (background == null || handle == null) return;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(background, eventData.position, eventData.pressEventCamera, out Vector2 p);
        Value = Vector2.ClampMagnitude(p / radius, 1f);
        handle.anchoredPosition = Value * radius;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        Value = Vector2.zero;
        if (handle != null) handle.anchoredPosition = Vector2.zero;
    }
}
