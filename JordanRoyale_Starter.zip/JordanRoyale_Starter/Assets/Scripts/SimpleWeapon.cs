using UnityEngine;

public class SimpleWeapon : MonoBehaviour
{
    public Camera aimCamera;
    public float range = 100f;
    public float fireCooldown = 0.22f;
    public ParticleSystem muzzleFlash;
    float nextShot;

    void Update()
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButton(0)) Fire();
#endif
    }

    public void Fire()
    {
        if (Time.time < nextShot) return;
        nextShot = Time.time + fireCooldown;
        if (muzzleFlash != null) muzzleFlash.Play();
        if (aimCamera == null) aimCamera = Camera.main;
        if (aimCamera == null) return;
        if (Physics.Raycast(aimCamera.transform.position, aimCamera.transform.forward, out RaycastHit hit, range))
        {
            PracticeTarget target = hit.collider.GetComponentInParent<PracticeTarget>();
            if (target != null) target.Hit();
        }
    }
}
