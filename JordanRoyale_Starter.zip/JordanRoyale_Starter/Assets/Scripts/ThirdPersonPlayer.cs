using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class ThirdPersonPlayer : MonoBehaviour
{
    public float moveSpeed = 5.2f;
    public float gravity = -22f;
    public Transform cameraTransform;
    public VirtualJoystick joystick;
    public float turnSpeed = 12f;

    CharacterController controller;
    Vector3 verticalVelocity;

    void Awake() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        Vector2 input = joystick != null ? joystick.Value : Vector2.zero;
#if UNITY_EDITOR || UNITY_STANDALONE
        input += new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        input = Vector2.ClampMagnitude(input, 1f);
#endif
        Vector3 forward = cameraTransform != null ? cameraTransform.forward : transform.forward;
        Vector3 right = cameraTransform != null ? cameraTransform.right : transform.right;
        forward.y = 0; right.y = 0; forward.Normalize(); right.Normalize();
        Vector3 move = forward * input.y + right * input.x;
        if (move.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(move), turnSpeed * Time.deltaTime);
        if (controller.isGrounded && verticalVelocity.y < 0) verticalVelocity.y = -2f;
        verticalVelocity.y += gravity * Time.deltaTime;
        controller.Move((move * moveSpeed + verticalVelocity) * Time.deltaTime);
    }
}
