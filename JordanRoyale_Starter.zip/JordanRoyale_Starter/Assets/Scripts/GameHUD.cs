using UnityEngine;
using UnityEngine.UI;

public class GameHUD : MonoBehaviour
{
    public Text modeLabel;
    public Text statusLabel;
    public SimpleWeapon weapon;
    void Start()
    {
        if (modeLabel != null) modeLabel.text = "JORDAN ROYALE | TRAINING";
        if (statusLabel != null) statusLabel.text = "LEVEL 1  |  XP: 0  |  COINS: 0";
    }
    public void FirePressed() { if (weapon != null) weapon.Fire(); }
}
