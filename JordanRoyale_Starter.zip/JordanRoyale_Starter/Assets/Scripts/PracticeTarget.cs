using UnityEngine;

public class PracticeTarget : MonoBehaviour
{
    public int health = 3;
    public void Hit() { health--; if (health <= 0) Destroy(gameObject); }
}
